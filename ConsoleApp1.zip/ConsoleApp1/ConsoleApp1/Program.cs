﻿using System.Text.RegularExpressions;

string s = "Иван Иванов, возраст: 25, email: ivan.ivanov@mail.com, телефон: +7(900)123-45-67\r\nМария Петрова, возраст: 30, email: maria_pet@mail.ru, телефон: +7(950)456-78-90\r\nСергей Сергеев, возраст: 40, email: serg1983@yandex.ru, телефон: +7(495)111-22-33\r\nАнна Смирнова, возраст: 22, email: anna.smirnova@gmail.com, телефон: +7(812)987-65-4";
Regex regex = new Regex(@"");
MatchCollection matches = regex.Matches(s);
foreach (Match match in matches)
Console.WriteLine(match.Value);


//(@"[А-Я][а-я]* \w* *, возраст: ..")